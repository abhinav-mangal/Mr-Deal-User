#!/bin/sh
# This is a generated file; do not edit or check into version control.
export "FLUTTER_ROOT=/Users/ramprasad.a/Developer/flutter"
export "FLUTTER_APPLICATION_PATH=/Users/ramprasad.a/Documents/RamprasadA/project/razorpay-flutter/example"
export "COCOAPODS_PARALLEL_CODE_SIGN=true"
export "FLUTTER_TARGET=/Users/ramprasad.a/Documents/RamprasadA/project/razorpay-flutter/example/lib/main.dart"
export "FLUTTER_BUILD_DIR=build"
export "FLUTTER_BUILD_NAME=1.2.6"
export "FLUTTER_BUILD_NUMBER=1.2.6"
export "DART_DEFINES=Zmx1dHRlci5pbnNwZWN0b3Iuc3RydWN0dXJlZEVycm9ycz10cnVl,RkxVVFRFUl9XRUJfQVVUT19ERVRFQ1Q9dHJ1ZQ=="
export "DART_OBFUSCATION=false"
export "TRACK_WIDGET_CREATION=true"
export "TREE_SHAKE_ICONS=false"
export "PACKAGE_CONFIG=/Users/ramprasad.a/Documents/RamprasadA/project/razorpay-flutter/example/.dart_tool/package_config.json"
